package com.atividade;

import java.util.Random;

import javax.swing.JOptionPane;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		// instancia de objetos
		Random n = new Random();
		Pessoa usuario = new Pessoa(n.nextInt(9999));
		Telefone tel = new Telefone(n.nextInt(9999));
		Endereco end = new Endereco(n.nextInt(9999));
		
		// entrada de dados do usuario
		usuario.setNome(JOptionPane.showInputDialog("Nome:"));
		usuario.setCpf(JOptionPane.showInputDialog("CPF:"));
		usuario.setEmail(JOptionPane.showInputDialog("E-mail:"));
		
		// entrada de dados do endereço do usuario
		end.setCep(JOptionPane.showInputDialog("CEP:"));
		end.setUf(JOptionPane.showInputDialog("Unidade da federação"));
		end.setCidade(JOptionPane.showInputDialog("Cidade:"));
		end.setBairro(JOptionPane.showInputDialog("Bairro:"));
		end.setLogradouro(JOptionPane.showInputDialog("Logradouro:"));
		end.setComplemento(JOptionPane.showInputDialog("Complemento:"));
		end.setNumero(JOptionPane.showInputDialog("Nº:"));
		
		
		// repasse os dados do endereço para o usuario
		usuario.setEnd(end);
		
		
		// entrada de dados do telefone do usuaio
		tel.setTelContato(JOptionPane.showInputDialog("Telefone de contato:"));
		tel.setTelCelular(JOptionPane.showInputDialog("Telefone celular:"));
		
		// repasse os dados do telfone para o usuario
		usuario.setTel(tel);
		
		// saida de dados
		JOptionPane.showMessageDialog(null, "ID do usuário: " + usuario.getIdPessoa() + ".\nNome: " + usuario.getNome() + ".\nCPF: " + usuario.getCpf() + ".\nE-mail: " + usuario.getEmail() + ".\nEndereço:\nCEP; " +
		usuario.getEnd().getCep() + ".\nUF: " + usuario.getEnd().getUf() + ".\nCidade: " + usuario.getEnd().getCidade() + ".\nBairro: " + 
		usuario.getEnd().getBairro() + ".\nLogradouro: " + 
		usuario.getEnd().getLogradouro() + ".\nCompelemento: " +
		usuario.getEnd().getComplemento() + ".\nNúmero: " +
		usuario.getEnd().getNumero() + ".\nTELEFONE:\nContato: " + 
		usuario.getTel().getTelContato() + ".\nCelular: " + 
		usuario.getTel().getTelCelular() + ".");
				
	}

}
