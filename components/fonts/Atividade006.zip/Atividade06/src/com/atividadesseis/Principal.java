package com.atividadesseis;

import java.util.Random;

import javax.swing.JOptionPane;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// instacia objeto
		Random n = new Random();
		PessoaFisica usuario = new PessoaFisica(n.nextInt(1101));
		PessoaJuridica empresa = new PessoaJuridica(n.nextInt(2202), "Sociedade Anônima", 0);

		// vetores
		Object opcoesPessoa[] = { "Pessoa Físcia", "Pessoa Juridica", "Sair" };
		Object tiposSaguineos[] = { "A+", "A-", "B-", "B+", "O-", "O+", "AB-", "AB+" };
		Object cargo[] = { "Gerente de Projetos", "Analista de Projetos", "Analista de Requisito", "Desenvolvedor java"};
		Object opcaoPessoa;
		// loop
		do {

			// escolha de opções
			opcaoPessoa = JOptionPane.showInputDialog(null, "Tipos de pessoas",
					" Selecione o tipo de pessoa que deseja cadastrar:", JOptionPane.INFORMATION_MESSAGE, null,
					opcoesPessoa, opcoesPessoa[0]);

			// verifica a opção selecionada
			if (opcaoPessoa == "Pessoa Físcia") {

				// entrada de dados usuario
				usuario.setNome(JOptionPane.showInputDialog("Informe o nome: "));
				usuario.setRg(JOptionPane.showInputDialog("Informe o RG: "));
				usuario.setCpf(JOptionPane.showInputDialog("Informe o CPF: "));
				usuario.setEmail(JOptionPane.showInputDialog("Informe o E-mail: "));
				usuario.setEndereco(JOptionPane.showInputDialog("Informe o Endereço: "));
				usuario.setTelefone(JOptionPane.showInputDialog("Informe o Telefone: "));
				usuario.setPeso(Double.parseDouble(JOptionPane.showInputDialog("Informe o Peso: ").replace(",", ".")));
				usuario.setAltura(Double.parseDouble(JOptionPane.showInputDialog("Informe a Altura: ").replace(",", ".")));
				usuario.setTipoSanguineo(JOptionPane.showInputDialog(null, "Tipo Saguíneo",
						"Informe o seu tipo sanguíneo:", JOptionPane.INFORMATION_MESSAGE, null, tiposSaguineos, tiposSaguineos[0]));
				usuario.setCargo(JOptionPane.showInputDialog(null, "CARGOS", "Informe seu cargo na empresa:",
						JOptionPane.INFORMATION_MESSAGE, null, cargo, cargo[0]));

				// saída de dados pessoa física

				JOptionPane.showMessageDialog(
						null, "PESSOA FÍSICA: \n\nID: " + usuario.getIdPessoa() +  ".\nNome: " + usuario.getNome() + ".\nCPF: " + usuario.getCpf() + ".\nRG: " + usuario.getRg() + ".\nE-mail: " + usuario.getEmail() + ".\nEndereço: " + usuario.getEndereco() + ".\nTelefone: " + usuario.getTelefone() + ".\nPeso: " + usuario.getPeso() + "kg.\nAltura " + usuario.getAltura() + ".\nTipo Sanguíneo: " + usuario.getTipoSanguineo() + ".\nCargo: " + usuario.getCargo() + ".\nSalário: R$ " + String.format("%.2f", usuario.receberSalario(usuario.getCargo())) +  ".");

			} else if (opcaoPessoa == "Pessoa Juridica") {

				// entrada de dados empresa
				empresa.setRazaoSocial(JOptionPane.showInputDialog("Informe a Razão Social da Empresa: "));
				empresa.setNomeFantasia(JOptionPane.showInputDialog("Informe o Nome Fantasia da Empresa: "));
				empresa.setCnpj(JOptionPane.showInputDialog("Informe o CNPJ da empresa: "));
				empresa.setTipoEmpresa(JOptionPane.showInputDialog("Informe o Tipo da empresa: "));
				
				empresa.setEmail(JOptionPane.showInputDialog("Informe o E-mail: "));
				empresa.setEndereco(JOptionPane.showInputDialog("Informe o Endereço: "));
				empresa.setTelefone(JOptionPane.showInputDialog("Informe o Telefone: "));
				empresa.alterarValorMercado(Double.parseDouble(JOptionPane.showInputDialog("Informe o atual valor das ações da empresa:").replace(",", ".")));

				// saída de dados

				JOptionPane.showMessageDialog(null,
						"PESSOA JURÍDICA \n\nID: " + empresa.getIdPessoa() + ".\nRazão social: "
								+ empresa.getRazaoSocial() + ".\nNome Fantasia: " + empresa.getNomeFantasia()
								+ ".\nCNPJ: " + empresa.getCnpj() + ".\nTipo da empresa: " + empresa.getTipoEmpresa()
								+ ".\nE-mail: " + empresa.getEmail() + ".\nEndereço: " + empresa.getEndereco() + ".\nTelefone: " + empresa.getTelefone() + String.format("%.2f", empresa.getValorMercado()) + ".");

			} else
				JOptionPane.showMessageDialog(null, "Obrigado.");

		} while (opcaoPessoa != "Sair");
	}
}
