package com.atividadesseis;

public final class PessoaJuridica extends Pessoa {
	
	private String razaoSocial;
	private String nomeFantasia;
	private String cnpj;
	private String tipoEmpresa;
	private double valorMercado;

	public PessoaJuridica(int IdPessoa, String tipoEmpresa, double valorMercadoInicial) {
		super(IdPessoa);
		// TODO Auto-generated constructor stub
	}
	
	// métodos de ação
	public double alterarValorMercado(double valorAcoes) {
		this.valorMercado = valorAcoes * 2000000;
		return this.valorMercado;
	}
	// métodos de acesso

	public String getRazaoSocial() {
		return razaoSocial;
	}

	public void setRazaoSocial(String razaoSocial) {
		this.razaoSocial = razaoSocial;
	}

	public String getNomeFantasia() {
		return nomeFantasia;
	}

	public void setNomeFantasia(String nomeFantasia) {
		this.nomeFantasia = nomeFantasia;
	}

	public String getCnpj() {
		return cnpj;
	}

	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}

	public String getTipoEmpresa() {
		return tipoEmpresa;
	}

	public void setTipoEmpresa(String tipoEmpresa) {
		this.tipoEmpresa = tipoEmpresa;
	}

	public double getValorMercado() {
		return valorMercado;
	}

	public void setValorMercado(double valorMercado) {
		this.valorMercado = valorMercado;
	}

} 
