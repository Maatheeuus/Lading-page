package com.atividadesseis;

public final class PessoaFisica extends Pessoa {
	// atributos
	private String nome;
	private String cpf;
	private String rg;
	private Object tipoSanguineo;
	private Object cargo;
	private double salario;
	private double peso;
	private double altura;
	
	// construtor
	public PessoaFisica(int IdPessoa) {
		super(IdPessoa);
		// TODO Auto-generated constructor stub
	}
	
	// métodos de ação
	
	public double receberSalario(Object cargo) {

	
		if (cargo == "Gerente de Projetos")
			this.salario = 9700;
		else if (cargo == "Analista de Projetos")
			this.salario = 5100;
		else if (cargo == "Analista de Requisito")
			this.salario = 4200;
		else if (cargo == "Desenvolvedor java")
			this.salario = 3700;
		
		return this.salario;

	}
	
	

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getRg() {
		return rg;
	}

	public void setRg(String rg) {
		this.rg = rg;
	}

	public Object getTipoSanguineo() {
		return tipoSanguineo;
	}

	public Object setTipoSanguineo(Object tipoSanguineo) {
		return this.tipoSanguineo = tipoSanguineo;
	}

	public Object getCargo() {
		return cargo;
	}

	public void setCargo(Object cargo) {
		this.cargo = cargo;
	}

	public double getSalario() {
		return salario;
	}

	public void setSalario(double salario) {
		this.salario = salario;
	}

	public double getPeso() {
		return peso;
	}

	public void setPeso(double peso) {
		this.peso = peso;
	}

	public double getAltura() {
		return altura;
	}

	public void setAltura(double altura) {
		this.altura = altura;
	}

	public void setPeso(String showInputDialog) {
		// TODO Auto-generated method stub

	}

	public void setAltura(String showInputDialog) {
		// TODO Auto-generated method stub

	}

	public void getTipoSanguineo(Object showInputDialog) {
		// TODO Auto-generated method stub
		
	}

	public void getCargo(Object showInputDialog) {
		// TODO Auto-generated method stub
		
	}

	

}
