package com.atividadesseis;

public abstract class Pessoa {
	// atributos
	private int idPessoa;
	private String email;
	private String endereco;
	private String telefone;
	private double salario;

	public Pessoa(int IdPessoa) {
// TODO Auto-generated constructor stub
		this.idPessoa = idPessoa;

	}

	

	public int getIdPessoa() {
		return idPessoa;
	}

	public void setIdPessoa(int idPessoa) {
		this.idPessoa = idPessoa;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

}
